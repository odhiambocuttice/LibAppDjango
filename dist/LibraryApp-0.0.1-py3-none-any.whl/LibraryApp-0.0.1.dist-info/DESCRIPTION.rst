===========
Library App
===========

Simple django library app



Quick start
=========

Just run: python3 manage.py runserver

